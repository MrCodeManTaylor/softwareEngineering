_README_
=========================================================================================================

**Stocks N Stuff Repository**

_Developed by: @pfears - Paul F.,@fwfiricano - Frank F.,@MrCodeManTaylor - Mitchell T._


_Fitchburg State University | CSC 4400-01 Software Engineering |Spring 2019 |Dr. N. Mahadev_

Update: 4/26/2019
 * Change to README.md
 * Added some functionality to the forum subfunctions **WIP**
 * Added multithreading capability for Main()
 * Added automatic live stock table updating and HTML Webscraping utils
 * LiveStock current build - WIP
 * Minor tweaks to Main() class for session control flow, browse 
      functionality implemented for stock filtering.
 * Minor tweaking of functional requirements, Main() Class beginning to be built for full session control
 * Browse-able stock data on Guest GUI complete *User GUI **WIP*
 * Recover user credentials functionality complete
 * Massive update to session control (LOGIN/LOGOUT FUNCTIONALITY COMPLETE) run GuestGUIMain for testing
 * Added jsoup.jar library for web scraping utilization
 * Added javamail.jar library for email verification
 * Setting up testing procedure for web scraped html parsing
 * Website for web scraping stock data http://www.wsj.com/mdc/public/page/2_3024-NYSE.html
